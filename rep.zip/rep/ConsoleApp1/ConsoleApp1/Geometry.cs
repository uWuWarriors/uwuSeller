﻿using System;

namespace ConsoleApp1
{
    class Geomentry
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
