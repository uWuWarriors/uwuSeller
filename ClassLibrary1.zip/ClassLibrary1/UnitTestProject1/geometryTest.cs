﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClassLibrary1;

namespace UnitTestProject1
{
    [TestClass]
    public class geometryTest
    {
        [TestMethod]
        public void RectangleArrea_Test()
        {
            int a = 3;
            int b = 5;
            int expected = 15;
            Geometry g = new Geometry();
            int actual = g.RectangleArea(a, b);
            Assert.AreEqual(expected, actual);
        }
    }
}
