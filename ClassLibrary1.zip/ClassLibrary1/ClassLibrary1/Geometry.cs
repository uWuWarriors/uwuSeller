﻿

namespace ClassLibrary1
{
    public class Geometry
    {
        public int RectangleArea(int a, int b)
        {
            return a * b;
        }
    }
}
