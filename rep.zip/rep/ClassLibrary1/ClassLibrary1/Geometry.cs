﻿

namespace ClassLibrary1
{
    public class Geometry
    {
        public double cylinderOB(double r, double h)
        {
            return r * h;
        }
    }
}
