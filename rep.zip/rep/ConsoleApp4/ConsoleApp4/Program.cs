﻿using System;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] str = Console.ReadLine().Split(" ");
            int a = int.Parse(str[0]);
            int b = int.Parse(str[1]);
            int c = int.Parse(str[2]);
            if (a == b && b == c) Console.WriteLine("равносторонний");
            else {
                if (a == b && b == c && a == c) Console.WriteLine("равнобедренный");
                else Console.WriteLine("разносторонний");
            }
        }
    }
}
