using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClassLibrary1;

namespace UnitTestProject1
{
    [TestClass]
    public class geometryTest
    {
        [TestMethod]
        public void cylinderPl_Test()
        {
            double r = 3;
            double h = 5;
            double expected = 15;
            Geometry g = new Geometry();
            double actual = g.cylinderPL(r, h);
            Assert.AreEqual(expected, actual);
        }
    }
}
